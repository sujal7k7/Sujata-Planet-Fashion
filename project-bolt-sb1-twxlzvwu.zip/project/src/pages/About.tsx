import React from 'react';

const About = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">About Sujata Planet Fashion</h1>
      
      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <img
            src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?ixlib=rb-4.0.3"
            alt="Fashion Store"
            className="w-full h-[400px] object-cover rounded-lg"
          />
        </div>
        
        <div className="space-y-6">
          <p className="text-lg">
            Welcome to Sujata Planet Fashion, your premier destination for contemporary fashion. 
            Established with a passion for style and quality, we bring you the latest trends from 
            around the world.
          </p>
          
          <p className="text-lg">
            Our carefully curated collection features pieces that combine elegance with comfort, 
            ensuring that you not only look good but feel confident in what you wear.
          </p>
          
          <div className="grid grid-cols-2 gap-4 mt-8">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <h3 className="text-2xl font-bold text-gray-900">1000+</h3>
              <p className="text-gray-600">Products</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <h3 className="text-2xl font-bold text-gray-900">50+</h3>
              <p className="text-gray-600">Brands</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;