import React from 'react';

const FilterSidebar = () => {
  const categories = ['All', 'Women', 'Men', 'Accessories'];
  const priceRanges = ['Under $50', '$50 - $100', '$100 - $200', 'Over $200'];

  return (
    <div className="w-full md:w-64 space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-3">Categories</h3>
        <div className="space-y-2">
          {categories.map((category) => (
            <label key={category} className="flex items-center">
              <input type="checkbox" className="mr-2" />
              {category}
            </label>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-3">Price Range</h3>
        <div className="space-y-2">
          {priceRanges.map((range) => (
            <label key={range} className="flex items-center">
              <input type="checkbox" className="mr-2" />
              {range}
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;